﻿using BasicWebAPI.Data;
using BasicWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicWebAPI.Controllers
{
    [Route("api/companies")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CompanyController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetCompanies()
        {
            var companies = _context.Companies.ToList();
            return Ok(companies);
        }

        [HttpPost]
        public IActionResult CreateCompany([FromBody] Company company)
        {
            if (company == null)
            {
                return BadRequest();
            }

            _context.Companies.Add(company);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetCompanies), new { id = company.CompanyId }, company);
        }

        [HttpGet("{id}")]
        public IActionResult GetCompany(int id)
        {
            var company = _context.Companies.Find(id);

            if (company == null)
            {
                return NotFound();
            }

            return Ok(company);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCompany(int id, [FromBody] Company updatedCompany)
        {
            if (updatedCompany == null || id != updatedCompany.CompanyId)
            {
                return BadRequest();
            }

            var existingCompany = _context.Companies.Find(id);

            if (existingCompany == null)
            {
                return NotFound();
            }

            existingCompany.CompanyName = updatedCompany.CompanyName;

            _context.SaveChanges();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCompany(int id)
        {
            var company = _context.Companies.Find(id);

            if (company == null)
            {
                return NotFound();
            }

            _context.Companies.Remove(company);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
