﻿using BasicWebAPI.Data;
using BasicWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicWebAPI.Controllers
{
    [Route("api/contacts")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ContactController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetContacts()
        {
            var contacts = _context.Contacts.Include(c => c.Company).Include(c => c.Country).ToList();
            return Ok(contacts);
        }

        [HttpPost]
        public IActionResult CreateContact([FromBody] Contact contact)
        {
            if (contact == null)
            {
                return BadRequest();
            }

            var existingCompany = _context.Companies.Find(contact.CompanyId);
            var existingCountry = _context.Countries.Find(contact.CountryId);

            if (existingCompany == null || existingCountry == null)
            {
                return NotFound("Company or Country not found");
            }

            
            var newContact = new Contact
            {
                ContactName = contact.ContactName,
                CompanyId = contact.CompanyId,
                CountryId = contact.CountryId
            };



            _context.Contacts.Add(newContact);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetContacts), new { id = newContact.ContactId }, newContact);
        }

        [HttpGet("{id}")]
        public IActionResult GetContact(int id)
        {
            var contact = _context.Contacts.Include(c => c.Company).Include(c => c.Country).FirstOrDefault(c => c.ContactId == id);

            if (contact == null)
            {
                return NotFound();
            }

            return Ok(contact);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateContact(int id, [FromBody] Contact updatedContact)
        {
            if (updatedContact == null || id != updatedContact.ContactId)
            {
                return BadRequest();
            }

            var existingContact = _context.Contacts.Find(id);

            if (existingContact == null)
            {
                return NotFound();
            }

            existingContact.ContactName = updatedContact.ContactName;
            existingContact.CompanyId = updatedContact.CompanyId;
            existingContact.CountryId = updatedContact.CountryId;

            _context.SaveChanges();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContact(int id)
        {
            var contact = _context.Contacts.Find(id);

            if (contact == null)
            {
                return NotFound();
            }

            _context.Contacts.Remove(contact);
            _context.SaveChanges();

            return NoContent();
        }

        [HttpGet("contactsWithCompanyAndCountry")]
        public IActionResult GetContactsWithCompanyAndCountry()
        {
            var contacts = _context.Contacts.Include(c => c.Company).Include(c => c.Country).ToList();
            return Ok(contacts);
        }

        [HttpGet("filterContacts")]
        public IActionResult FilterContacts(int? countryId, int? companyId)
        {
            IQueryable<Contact> filteredContacts = _context.Contacts;

            if (countryId.HasValue)
            {
                filteredContacts = filteredContacts.Where(c => c.CountryId == countryId.Value);
            }

            if (companyId.HasValue)
            {
                filteredContacts = filteredContacts.Where(c => c.CompanyId == companyId.Value);
            }

            var resultContacts = filteredContacts.Include(c => c.Country) .Include(c => c.Company).Select(c => new
       {
           c.ContactId,
           c.ContactName,
           CountryId = c.Country.CountryId,
           c.Country.CountryName,
           CompanyId = c.Company.CompanyId,
           c.Company.CompanyName
       }).ToList();

            return Ok(resultContacts);
        }
    }
}
