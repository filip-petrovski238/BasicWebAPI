﻿using BasicWebAPI.Data;
using BasicWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicWebAPI.Controllers
{
    [Route("api/countries")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CountryController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetCountries()
        {
            var countries = _context.Countries.ToList();
            return Ok(countries);
        }

        [HttpPost]
        public IActionResult CreateCountry([FromBody] Country country)
        {
            if (country == null)
            {
                return BadRequest();
            }

            _context.Countries.Add(country);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetCountries), new { id = country.CountryId }, country);
        }

        [HttpGet("{id}")]
        public IActionResult GetCountry(int id)
        {
            var country = _context.Countries.Find(id);

            if (country == null)
            {
                return NotFound();
            }

            return Ok(country);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCountry(int id, [FromBody] Country updatedCountry)
        {
            if (updatedCountry == null || id != updatedCountry.CountryId)
            {
                return BadRequest();
            }

            var existingCountry = _context.Countries.Find(id);

            if (existingCountry == null)
            {
                return NotFound();
            }

            existingCountry.CountryName = updatedCountry.CountryName;

            _context.SaveChanges();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCountry(int id)
        {
            var country = _context.Countries.Find(id);

            if (country == null)
            {
                return NotFound();
            }

            _context.Countries.Remove(country);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
